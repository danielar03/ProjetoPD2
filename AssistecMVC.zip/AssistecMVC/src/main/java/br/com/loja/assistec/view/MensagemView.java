package br.com.loja.assistec.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MensagemView  extends JDialog {
	
 private static final long serialVersionUID = 1L;
 
 public MensagemView(String mensagem, int tipo) {
	 setTitle("Mensagem");
	 setModal(true);
	 //criar panel
	 JPanel panel = new JPanel();
	 panel.setLayout(new BorderLayout());
	 add(panel);
	 
	 //Rotulo para mensagem
	 JLabel lblMensagem = new JLabel (mensagem, SwingConstants.CENTER);
	 panel.add(lblMensagem, BorderLayout.CENTER);
	 
	 //caminho do icone
	 String iconePath;
	 switch(tipo) {
	 case 0: //erro
		 iconePath ="/br/com/loja/assistec/icones/erro.png";
		 lblMensagem.setIcon(new ImgIcon(getClass().getResource(iconPath)));	
		 break;
	 case 1: //informacao
		 iconePath ="/br/com/loja/assistec/icones/informacao.png";
		 lblMensagem.setIcon(new ImgIcon(getClass().getResource(iconPath)));
		 break;
	 case 2: //alerta
		 iconePath ="/br/com/loja/assistec/icones/alerta.png";
		 lblMensagem.setIcon(new ImgIcon(getClass().getResource(iconPath)));
		 break;
	 case 3: //sucesso
		 iconePath ="/br/com/loja/assistec/icones/sucesso.png";
		 lblMensagem.setIcon(new ImgIcon(getClass().getResource(iconPath)));
		 break;
	 case 10: //assistec
		 iconePath ="/br/com/loja/assistec/icones/assistec.png";
		 lblMensagem.setIcon(new ImgIcon(getClass().getResource(iconPath)));
		 break;
	 }
	 
	 JPanel painelSul = new JPaneil(new FlowLayout(FlowLayout.CENTER, 20, 10));
	 //cria um espaço vazio
	 painelSul.add(new JPanel());
	 JButton btnOK =new JButton("ok");
	 btnOK.addActionListener(new ActionListener() {
		 @Override 
		 public void actionPerforme(ActionEvent e) {
			 setVisible(false);
		 }
		 
	 });
	 painelSul.add(btnOK);
	 painelSul.add(new JPanel());
	 panel.add(paneilSul, BorderLayout.SOUTH);
	 
	 setSize(350, 200);
	 setLocationRelativeTo(null);
	 setVisible(true);
	 
	 }
	

}
